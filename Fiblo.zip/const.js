module.exports = {
  ROL_ADMIN: "8602f10dea"
};
